export enum CorePartDepend{
    engineSysterm,
    suspension,
}