export enum PartType{
    INTERIOR,
    CORE,
    CONSUMABLE,

}